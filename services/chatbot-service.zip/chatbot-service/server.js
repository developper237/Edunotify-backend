
require('dotenv').config({ path: require('path').resolve(__dirname, '.env') });

const express    = require('express');
const cors       = require('cors');
const chatRoutes = require('./chat.routes');

const app  = express();
const PORT = process.env.CHATBOT_PORT || 8085;

app.use(cors());
app.use(express.json());

// Routes chatbot
app.use('/api/chat', chatRoutes);

// Health check
app.get('/health', (_, res) => res.json({
  status:    'ok',
  service:   'chatbot-service',
  timestamp: new Date().toISOString(),
}));

app.listen(PORT, '0.0.0.0', () => {
  console.log(`--------------------------------------------------`);
  console.log(`[Chatbot Service] Démarré avec succès !`);
  console.log(`[Chatbot Service] Port : ${PORT}`);
  console.log(`--------------------------------------------------`);
});
// Force le processus Node.js à rester actif et ne pas quitter
setInterval(() => {
  // Une tâche vide toutes les heures maintient la boucle d'événements ouverte
}, 1000 * 60 * 60);