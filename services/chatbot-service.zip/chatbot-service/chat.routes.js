const express = require('express');
const router = express.Router();
const { handleChatMessage, getChatHistory } = require('./chat.controller');

// L'URL finale sera : POST http://192.168.1.203:8085/api/chat
router.post('/', handleChatMessage); 

// L'URL finale sera : GET http://192.168.1.203:8085/api/chat/history
router.get('/history', getChatHistory); 

module.exports = router;