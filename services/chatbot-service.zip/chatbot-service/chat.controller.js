const { GoogleGenerativeAI } = require('@google/generative-ai');

// Prisma client partagé — services/node_modules/.prisma/client
const { PrismaClient } = require('../node_modules/.prisma/client');

const genAI  = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const prisma = new PrismaClient();

// ══════════════════════════════════════════════════════════════════
// DÉCLARATIONS DES OUTILS GEMINI
// ══════════════════════════════════════════════════════════════════

const getStudentProfileDeclaration = {
  name: 'getStudentProfile',
  description: "Récupère les informations personnelles de l'étudiant connecté (Nom, prénom, filière). Ne demande aucun paramètre à l'utilisateur.",
  parameters: {
    type: 'OBJECT',
    properties: {}, 
  },
};

const getStudentNotesDeclaration = {
  name: 'getStudentNotes',
  description: "Récupère les notes réelles et la moyenne générale de l'étudiant connecté. Ne demande aucun paramètre à l'utilisateur.",
  parameters: {
    type: 'OBJECT',
    properties: {},
  },
};

const getStudentAbsencesDeclaration = {
  name: 'getStudentAbsences',
  description: "Récupère le nombre d'absences de l'étudiant connecté. Ne demande aucun paramètre à l'utilisateur.",
  parameters: {
    type: 'OBJECT',
    properties: {},
  },
};

// ══════════════════════════════════════════════════════════════════
// FONCTIONS RÉELLES — REQUÊTES PRISMA
// ══════════════════════════════════════════════════════════════════

async function getStudentProfile(studentId) {
  try {
    const etudiant = await prisma.etudiant.findUnique({
      where: { id: studentId },
      include: { filiere: true }
    });
    if (!etudiant) return { error: "Profil introuvable." };
    return {
      statut: "Succès",
      nom: etudiant.nom,
      prenom: etudiant.prenom,
      filiere: etudiant.filiere?.nom ?? "Non assignée"
    };
  } catch (err) {
    console.error('[getStudentProfile]', err.message);
    return { error: "Impossible de récupérer le profil." };
  }
}

async function getStudentNotes(studentId) {
  try {
    const notes = await prisma.note.findMany({
      where: { etudiantId: studentId },
      include: {
        matiere: { select: { nom: true, coefficient: true } },
      },
      orderBy: { matiere: { nom: 'asc' } },
    });

    if (notes.length === 0) {
      return {
        studentId,
        statut: 'Aucune note disponible pour le moment.',
        notes: [],
        moyenneGenerale: null,
      };
    }

    let somme = 0;
    let totalCoeff = 0;
    const notesFormatees = notes.map((n) => {
      const coeff = n.matiere?.coefficient ?? 1;
      somme       += n.valeur * coeff;
      totalCoeff  += coeff;
      return {
        matiere:     n.matiere?.nom ?? 'Inconnue',
        note:        n.valeur,
        coefficient: coeff,
        publieLe:     n.publication?.publieLe ?? null,
      };
    });

    const moyenne = totalCoeff > 0
      ? Math.round((somme / totalCoeff) * 100) / 100
      : null;

    return {
      studentId,
      statut: 'Succès',
      notes:  notesFormatees,
      moyenneGenerale: moyenne,
    };
  } catch (err) {
    console.error('[getStudentNotes]', err.message);
    return { error: 'Impossible de récupérer les notes pour le moment.' };
  }
}

async function getStudentAbsences(studentId) {
  try {
    const presences = await prisma.presence.findMany({
      where: { userId: studentId },
      include: {
        session: {
          select: {
            matiere:    true,
            professeur: true,
            type:       true,
            ouverteLe:  true,
          },
        },
      },
      orderBy: { session: { ouverteLe: 'desc' } },
    });

    const absences = presences.filter((p) => p.statut === 'absent' || p.statut === 'ABSENT');
    const presents = presences.filter((p) => p.statut === 'present' || p.statut === 'PRESENT');

    return {
      studentId,
      statut:        'Succès',
      totalSeances:  presences.length,
      totalPresents: presents.length,
      totalAbsences: absences.length,
      tauxPresence: presences.length > 0 ? `${Math.round((presents.length / presences.length) * 100)}%` : 'N/A',
      details: absences.map((a) => ({
        matiere:    a.session?.matiere    ?? 'Inconnue',
        professeur: a.session?.professeur ?? '',
        type:       a.session?.type       ?? '',
        date:       a.session?.ouverteLe  ?? null,
      })),
    };
  } catch (err) {
    console.error('[getStudentAbsences]', err.message);
    return { error: "Impossible de récupérer les absences pour le moment." };
  }
}

// ══════════════════════════════════════════════════════════════════
// NOUVEAU MODULE : RÉCUPÉRATION DE L'HISTORIQUE DEPUIS POSTGRESQL
// ══════════════════════════════════════════════════════════════════
const getChatHistory = async (req, res) => {
  try {
    const studentId = req.headers['x-user-id'];
    if (!studentId) {
      return res.status(401).json({ error: 'Utilisateur non identifié.' });
    }

    // Récupération des 50 derniers messages pour cet étudiant
    const messages = await prisma.chatMessage.findMany({
      where: { etudiantId: studentId },
      orderBy: { createdAt: 'asc' },
      take: 50,
    });

    return res.status(200).json(messages);
  } catch (err) {
    console.error('[getChatHistory Error]', err);
    return res.status(500).json({ error: "Impossible de charger l'historique." });
  }
};

// ══════════════════════════════════════════════════════════════════
// CONTRÔLEUR PRINCIPAL DE CHAT
// ══════════════════════════════════════════════════════════════════
const handleChatMessage = async (req, res) => {
  try {
    const { message, history } = req.body;
    const studentId = req.headers['x-user-id'];

    if (!message) return res.status(400).json({ error: 'Le message est requis.' });
    if (!studentId) return res.status(401).json({ error: 'Utilisateur non identifié.' });

    // 1. Sauvegarde immédiate du message de l'étudiant dans PostgreSQL
    await prisma.chatMessage.create({
      data: {
        text: message,
        isUser: true,
        etudiantId: studentId,
      },
    });

    const model = genAI.getGenerativeModel({
      model: 'gemini-2.5-flash',
      tools: [{
        functionDeclarations: [
          getStudentProfileDeclaration,
          getStudentNotesDeclaration,
          getStudentAbsencesDeclaration,
        ],
      }],
    });

    const systemInstruction =
      "Tu es SmartCampus Assistant, l'IA intégrée à l'application EduNotify. " +
      "Tu aides l'étudiant connecté concernant son identité, ses notes, ses absences et son emploi du temps. " +
      "Réponds toujours en français de manière concise, claire et bienveillante.\n\n" +
      "CONTEXTE DE SÉCURITÉ :\n" +
      `- L'étudiant actuel a l'identifiant unique : "${studentId}".\n` +
      "- Tu possèdes déjà son identifiant en arrière-plan. Ne lui demande JAMAIS son ID ou ses informations d'authentification.\n\n" +
      "RÈGLES D'EXÉCUTION DES FONCTIONS (OUTILS) :\n" +
      "- Déclenche la fonction 'getStudentNotes' UNIQUEMENT si l'étudiant demande explicitement ses notes, ses résultats ou ses moyennes.\n" +
      "- Déclenche la fonction 'getStudentAbsences' UNIQUEMENT si l'étudiant pose une question sur ses absences, ses présences ou ses séances manquées.\n" +
      "- Déclenche la fonction 'getStudentProfile' UNIQUEMENT si l'étudiant te demande son nom, son prénom, qui il est ou ses infos de profil.\n" +
      "- Si l'étudiant te salue simplement (ex: 'bonjour', 'salut', 'ça va ?'), NE DÉCLENCHE AUCUNE FONCTION.";

    const formattedHistory = Array.isArray(history) ? history : [];

    const chat = model.startChat({
      systemInstruction: { parts: [{ text: systemInstruction }] },
      history: formattedHistory, 
    });

    let result = await chat.sendMessage(message);
    const functionCalls = result.response.functionCalls;

    if (functionCalls && functionCalls.length > 0) {
      const call = functionCalls[0];
      console.log(`[Gemini] Dynamic Call: ${call.name} pour ${studentId}`);

      let functionResult;
      if (call.name === 'getStudentProfile') {
        functionResult = await getStudentProfile(studentId);
      } else if (call.name === 'getStudentNotes') {
        functionResult = await getStudentNotes(studentId);
      } else if (call.name === 'getStudentAbsences') {
        functionResult = await getStudentAbsences(studentId);
      }

      result = await chat.sendMessage([{
        functionResponse: {
          name: call.name,
          response: functionResult,
        },
      }]);
    }

    const responseText = result.response.text();

    // 2. Sauvegarde de la réponse générée par l'IA dans PostgreSQL
    await prisma.chatMessage.create({
      data: {
        text: responseText,
        isUser: false,
        etudiantId: studentId,
      },
    });

    return res.status(200).json({ reply: responseText });

  } catch (err) {
    console.error('[Chatbot System Error]', err);
    return res.status(500).json({
      reply: "Désolé, mon module de réflexion rencontre des difficultés. Réessaie dans un instant !",
    });
  }
};

module.exports = { handleChatMessage, getChatHistory };